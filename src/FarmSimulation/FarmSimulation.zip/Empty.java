package FarmSimulation;


class Empty extends FarmObject {
    @Override
    public String toString() {
        return " ";
    }
}

