package FarmSimulation;

class Gate extends FarmObject {
    @Override
    public String toString() {
        return " ";
    }
}

