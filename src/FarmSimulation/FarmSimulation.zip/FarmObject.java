package FarmSimulation;

class FarmObject {
    @Override
    public String toString() {
        return " ";
    }
}
