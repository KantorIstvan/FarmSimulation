package FarmSimulation;


class Wall extends FarmObject {
    @Override
    public String toString() {
        return "#";
    }
}

